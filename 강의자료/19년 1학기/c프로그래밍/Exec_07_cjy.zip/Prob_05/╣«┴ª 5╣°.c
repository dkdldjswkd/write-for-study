#include <stdio.h>

int fact(int n) {
	if (n == 1)return 1;
	return n * fact(n - 1);
}

double e(int n) {
	double E = 1;
	int a = 0;
	for (int i = 1; i <= n; i++) {
		//if (i == 1)E = E + 1;
		E = E + ((double)1 / (double)fact(i));
	}
	return E;
}

int main() {
	printf("������ ��� �ұ��? n�� �Է� : ");
	int n; scanf_s("%d", &n);
	printf("%lf", e(n));
}